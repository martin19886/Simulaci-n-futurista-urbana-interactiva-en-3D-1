
import React, { useRef, useEffect, useState } from 'react';
import { useFrame } from '@react-three/fiber';
import { Box, Cone } from '@react-three/drei';
import * as THREE from 'three';
import { PlayerInput, EntityState } from '../../types';
import { 
  VEHICLE_SPEED, VEHICLE_ROTATION_SPEED, VEHICLE_TURBO_MULTIPLIER, VEHICLE_TURBO_DURATION,
  AIRPLANE_TAKEOFF_SPEED, AIRPLANE_FLYING_SPEED, AIRPLANE_CLIMB_RATE, AIRPLANE_ROLL_RATE, RUNWAY_Y
} from '../../constants';

// Runway area approx. based on Runway component: position [20, RUNWAY_Y - 0.5, 20], size [8, 1, 40]
const RUNWAY_X_MIN = 20 - 4;
const RUNWAY_X_MAX = 20 + 4;
const RUNWAY_Z_MIN = 20 - 20;
const RUNWAY_Z_MAX = 20 + 20;
const MAX_ALTITUDE = 50;


interface AirplaneProps {
  initialState: EntityState;
  playerInput: PlayerInput;
  isActive: boolean;
  onStateChange: (state: EntityState) => void;
  objectRef?: React.MutableRefObject<THREE.Object3D | null>;
}

export const Airplane: React.FC<AirplaneProps> = ({ initialState, playerInput, isActive, onStateChange, objectRef }) => {
  const groupRef = useRef<THREE.Group>(null!);
  const [isTurboActive, setIsTurboActive] = useState(false);
  const [isFlying, setIsFlying] = useState(false);
  const [currentSpeed, setCurrentSpeed] = useState(0);
  const turboTimeoutRef = useRef<number | null>(null); // Changed type to number

  useEffect(() => {
    if (groupRef.current) {
      groupRef.current.position.set(...initialState.position);
      groupRef.current.rotation.set(...initialState.rotation);
      if (isActive && objectRef) {
        objectRef.current = groupRef.current;
        // Reset state when becoming active
        setIsFlying(false); 
        setCurrentSpeed(0);
        groupRef.current.rotation.x = 0; // Level out pitch
        groupRef.current.rotation.z = 0; // Level out roll
      }
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isActive, objectRef]); // Reset on active

  useEffect(() => {
    if (isActive && playerInput.turbo && !isTurboActive) {
      setIsTurboActive(true);
      if (turboTimeoutRef.current) clearTimeout(turboTimeoutRef.current);
      turboTimeoutRef.current = window.setTimeout(() => { // Explicitly use window.setTimeout
        setIsTurboActive(false);
      }, VEHICLE_TURBO_DURATION);
    }
    // Cleanup timeout on component unmount or when dependencies change
     return () => {
      if (turboTimeoutRef.current) {
        clearTimeout(turboTimeoutRef.current);
      }
    };
  }, [isActive, playerInput.turbo, isTurboActive]);

  useFrame((_, delta) => {
    if (!isActive || !groupRef.current) return;

    let targetSpeed = 0;
    const acceleration = 5 * delta; // m/s^2
    const deceleration = 10 * delta;

    if (playerInput.forward) {
      targetSpeed = isFlying ? AIRPLANE_FLYING_SPEED : AIRPLANE_TAKEOFF_SPEED;
      if (isTurboActive) targetSpeed *= VEHICLE_TURBO_MULTIPLIER;
      setCurrentSpeed(prev => Math.min(prev + acceleration, targetSpeed));
    } else if (playerInput.backward) { // Braking / Slowing down
      targetSpeed = 0;
      setCurrentSpeed(prev => Math.max(prev - deceleration, targetSpeed));
    } else { // No throttle input
        if (isFlying) { // Maintain some speed if flying without throttle, or gradually slow
            setCurrentSpeed(prev => Math.max(prev - acceleration * 0.3, AIRPLANE_FLYING_SPEED * 0.5));
        } else {
            setCurrentSpeed(prev => Math.max(prev - acceleration * 0.5, 0)); // Slow down on ground
        }
    }
    
    groupRef.current.translateZ(-currentSpeed * delta);

    const isOnRunway = 
      groupRef.current.position.x >= RUNWAY_X_MIN && groupRef.current.position.x <= RUNWAY_X_MAX &&
      groupRef.current.position.z >= RUNWAY_Z_MIN && groupRef.current.position.z <= RUNWAY_Z_MAX;

    if (!isFlying) { // On ground
      groupRef.current.position.y = initialState.position[1]; // Stay on runway Y
      groupRef.current.rotation.x = 0; // No pitch on ground
      groupRef.current.rotation.z = 0; // No roll on ground

      // Steering on ground
      if (currentSpeed > 1) { // Only steer if moving
          if (playerInput.left) groupRef.current.rotateY(VEHICLE_ROTATION_SPEED * delta * (currentSpeed/5));
          if (playerInput.right) groupRef.current.rotateY(-VEHICLE_ROTATION_SPEED * delta * (currentSpeed/5));
      }

      // Takeoff logic
      if (playerInput.forward && currentSpeed >= AIRPLANE_TAKEOFF_SPEED * 0.8 && isOnRunway) {
         // User pulls "up" implicitly by holding W at speed on runway
         setIsFlying(true);
      }
    } else { // Flying
      // Pitch (Climb/Descend) - W for up, S for down (inverted from typical flight sims for simplicity)
      if (playerInput.forward && groupRef.current.position.y < MAX_ALTITUDE) {
        groupRef.current.position.y += AIRPLANE_CLIMB_RATE * delta * (currentSpeed / AIRPLANE_FLYING_SPEED);
        groupRef.current.rotation.x = THREE.MathUtils.lerp(groupRef.current.rotation.x, -Math.PI / 12, delta * 2); // Pitch up
      } else if (playerInput.backward && groupRef.current.position.y > initialState.position[1] + 1) { // Descend, but not below ground + buffer
        groupRef.current.position.y -= AIRPLANE_CLIMB_RATE * delta * 1.5;
        groupRef.current.rotation.x = THREE.MathUtils.lerp(groupRef.current.rotation.x, Math.PI / 12, delta * 2); // Pitch down
      } else {
        groupRef.current.rotation.x = THREE.MathUtils.lerp(groupRef.current.rotation.x, 0, delta); // Level out pitch
      }

      // Roll (Turn)
      if (playerInput.left) {
        groupRef.current.rotateY(AIRPLANE_ROLL_RATE * delta * (currentSpeed / AIRPLANE_FLYING_SPEED));
        groupRef.current.rotation.z = THREE.MathUtils.lerp(groupRef.current.rotation.z, Math.PI / 8, delta * 2); // Roll left
      } else if (playerInput.right) {
        groupRef.current.rotateY(-AIRPLANE_ROLL_RATE * delta * (currentSpeed / AIRPLANE_FLYING_SPEED));
        groupRef.current.rotation.z = THREE.MathUtils.lerp(groupRef.current.rotation.z, -Math.PI / 8, delta * 2); // Roll right
      } else {
        groupRef.current.rotation.z = THREE.MathUtils.lerp(groupRef.current.rotation.z, 0, delta * 2); // Level out roll
      }
      
      // Landing logic
      if (groupRef.current.position.y <= initialState.position[1] + 0.5 && isOnRunway && currentSpeed < AIRPLANE_TAKEOFF_SPEED * 0.7) {
        setIsFlying(false);
        groupRef.current.position.y = initialState.position[1];
        groupRef.current.rotation.x = 0;
        groupRef.current.rotation.z = 0;
      } else if (groupRef.current.position.y < initialState.position[1]) { // Crashed
        setIsFlying(false); // Force ground state
        setCurrentSpeed(0);
        groupRef.current.position.y = initialState.position[1];
         // Potentially add a "crashed" state visual or message
      }
    }
    
    onStateChange({
      position: groupRef.current.position.toArray() as [number, number, number],
      rotation: [groupRef.current.rotation.x, groupRef.current.rotation.y, groupRef.current.rotation.z],
    });
    if (objectRef) {
      objectRef.current = groupRef.current;
    }
  });

  return (
    <group ref={groupRef} castShadow receiveShadow visible={true}>
      {/* Fuselage */}
      <Box args={[1.5, 1, 6]} position={[0, 0, 0]} castShadow>
        <meshStandardMaterial color={isTurboActive ? "gold" : "silver"} metalness={0.7} roughness={0.2}/>
      </Box>
      {/* Wings */}
      <Box args={[7, 0.3, 1.5]} position={[0, 0.1, -0.5]} castShadow>
        <meshStandardMaterial color="lightgray" metalness={0.6} roughness={0.3}/>
      </Box>
      {/* Tail Fin */}
      <Box args={[0.3, 1.5, 1]} position={[0, 0.8, 2.7]} castShadow>
        <meshStandardMaterial color="darkgray" metalness={0.5} roughness={0.4}/>
      </Box>
      {/* Horizontal Stabilizer */}
       <Box args={[2.5, 0.2, 0.8]} position={[0, 0.2, 2.8]} castShadow>
        <meshStandardMaterial color="gray" metalness={0.5} roughness={0.4}/>
      </Box>
      {/* Cockpit */}
      <Cone args={[0.6, 0.8, 4]} position={[0, 0.3, -2.8]} rotation={[Math.PI/2, 0, 0]} castShadow>
         <meshStandardMaterial color="skyblue" transparent opacity={0.7} metalness={0.2} roughness={0.1}/>
      </Cone>
    </group>
  );
};
