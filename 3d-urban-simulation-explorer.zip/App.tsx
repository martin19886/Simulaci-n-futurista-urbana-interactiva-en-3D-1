
import React, { useState, useEffect, useCallback, useRef, Suspense } from 'react';
import { Canvas } from '@react-three/fiber';
import { Sky, Stats } from '@react-three/drei';
import { Scene } from './components/Scene';
import { ControlMode, PlayerInput, EntityState, GroundingChunk } from './types';
import { useInputControls } from './hooks/useInputControls';
import { FollowCamera } from './components/FollowCamera';
import { Character } from './components/Character';
import { Car } from './components/vehicles/Car';
import { Boat } from './components/vehicles/Boat';
import { Airplane } from './components/vehicles/Airplane';
import { INTERACTION_DISTANCE, CAMERA_OFFSET_CHARACTER, CAMERA_OFFSET_VEHICLE, GEMINI_MODEL_TEXT } from './constants';
import * as THREE from 'three';
import { GoogleGenAI, GenerateContentResponse, Chat } from '@google/genai';
import type { GroundingChunk as GenAIGroundingChunk } from '@google/genai';


const initialCharacterState: EntityState = { position: [0, 0.85, 5], rotation: [0, 0, 0] };
const initialCarState: EntityState = { position: [5, 0.4, -5], rotation: [0, Math.PI / 2, 0] };
const initialBoatState: EntityState = { position: [-15, 0.25, 15], rotation: [0, 0, 0] };
const initialAirplaneState: EntityState = { position: [20, 0.55, 20], rotation: [0, -Math.PI/2, 0] }; // On runway

const App: React.FC = () => {
  const [controlMode, setControlMode] = useState<ControlMode>(ControlMode.Character);
  const [characterState, setCharacterState] = useState<EntityState>(initialCharacterState);
  const [carState, setCarState] = useState<EntityState>(initialCarState);
  const [boatState, setBoatState] = useState<EntityState>(initialBoatState);
  const [airplaneState, setAirplaneState] = useState<EntityState>(initialAirplaneState);

  const [geminiMessage, setGeminiMessage] = useState<string>('');
  const [geminiLoading, setGeminiLoading] = useState<boolean>(false);
  const [geminiSources, setGeminiSources] = useState<GroundingChunk[]>([]);

  const playerInput = useInputControls();
  const controlledObjectRef = useRef<THREE.Object3D | null>(null);
  const aiRef = useRef<GoogleGenAI | null>(null);
  const chatRef = useRef<Chat | null>(null);

  useEffect(() => {
    if (process.env.API_KEY) {
      aiRef.current = new GoogleGenAI({ apiKey: process.env.API_KEY });
    } else {
      console.error("API_KEY environment variable not set. Gemini API functionality will be disabled.");
      setGeminiMessage("API_KEY not configured. AI guidance is unavailable.");
    }
  }, []);

  const getGeminiResponse = useCallback(async (prompt: string, useSearch: boolean = false) => {
    if (!aiRef.current) {
      setGeminiMessage("Gemini AI not initialized. Cannot fetch guidance.");
      return;
    }
    setGeminiLoading(true);
    setGeminiMessage('AI is thinking...');
    setGeminiSources([]);

    try {
      let response: GenerateContentResponse;
      if (!chatRef.current) {
         chatRef.current = aiRef.current.chats.create({
            model: GEMINI_MODEL_TEXT,
            config: {
              systemInstruction: 'You are a helpful assistant in a 3D simulation game. Provide concise guidance and descriptions. Format responses for easy reading in a small UI panel.',
              ...(useSearch ? { tools: [{ googleSearch: {} }] } : {})
            },
          });
      }
      
      response = await chatRef.current.sendMessage({ message: prompt });
      
      let text = response.text.trim();
      const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s;
      const match = text.match(fenceRegex);
      if (match && match[2]) {
        text = match[2].trim();
      }
      setGeminiMessage(text);

      const sourcesFromAPI: GenAIGroundingChunk[] = response.candidates?.[0]?.groundingMetadata?.groundingChunks ?? [];
      const filteredSources: GroundingChunk[] = sourcesFromAPI
        .filter(s => s.web?.uri) // Ensure URI exists
        .map(s => ({ // Map to our local GroundingChunk type
            web: {
                uri: s.web?.uri, // URI is now potentially undefined, but filter handles it
                title: s.web?.title,
            },
            retrievalQuery: s.retrievalQuery,
            text: s.text,
        }));
      setGeminiSources(filteredSources);

    } catch (error) {
      console.error('Error fetching from Gemini API:', error);
      setGeminiMessage('Error fetching AI guidance. Please try again.');
    } finally {
      setGeminiLoading(false);
    }
  }, []);

  useEffect(() => {
    getGeminiResponse("Welcome! Describe this minimalist, futuristic urban simulation. What can I do here? Controls: W/S/A/D to move/steer. E to interact. Shift for turbo in vehicles.");
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);


  const checkInteraction = useCallback(() => {
    if (!playerInput.interact || controlMode !== ControlMode.Character) return;

    const charPos = new THREE.Vector3(...characterState.position);
    const carPos = new THREE.Vector3(...carState.position);
    const boatPos = new THREE.Vector3(...boatState.position);
    const airplanePos = new THREE.Vector3(...airplaneState.position);

    if (charPos.distanceTo(carPos) < INTERACTION_DISTANCE) {
      setControlMode(ControlMode.Car);
      getGeminiResponse("I'm in the car! How do I drive it? Remind me of turbo.");
    } else if (charPos.distanceTo(boatPos) < INTERACTION_DISTANCE) {
      setControlMode(ControlMode.Boat);
      getGeminiResponse("I'm on the boat! How do I control it? Can it go on land?");
    } else if (charPos.distanceTo(airplanePos) < INTERACTION_DISTANCE) {
      setControlMode(ControlMode.Airplane);
      getGeminiResponse("I'm near the airplane on a runway. How do I fly it?");
    }
  }, [playerInput.interact, controlMode, characterState.position, carState.position, boatState.position, airplaneState.position, getGeminiResponse]);

  useEffect(() => {
    checkInteraction();
  }, [playerInput.interact, checkInteraction]);


  const handleExitVehicle = useCallback(() => {
    if (playerInput.interact && controlMode !== ControlMode.Character) {
       // Place character next to the vehicle
      let vehiclePosArray: [number, number, number];
      switch(controlMode) {
        case ControlMode.Car: vehiclePosArray = carState.position; break;
        case ControlMode.Boat: vehiclePosArray = boatState.position; break;
        case ControlMode.Airplane: vehiclePosArray = airplaneState.position; break;
        default: vehiclePosArray = [0,0,0]; // Should not happen
      }
      const vehicleExitPos = new THREE.Vector3(...vehiclePosArray).add(new THREE.Vector3(2, 0, 0)); // Offset slightly
      setCharacterState(prev => ({ ...prev, position: vehicleExitPos.toArray() as [number,number,number], rotation: prev.rotation }));
      setControlMode(ControlMode.Character);
      getGeminiResponse("I'm back on foot. What should I explore next?");
    }
  }, [playerInput.interact, controlMode, carState.position, boatState.position, airplaneState.position, getGeminiResponse]);

  useEffect(() => {
    handleExitVehicle();
  }, [playerInput.interact, handleExitVehicle]);


  const cameraOffset = controlMode === ControlMode.Character ? CAMERA_OFFSET_CHARACTER : CAMERA_OFFSET_VEHICLE;

  return (
    <>
      <Canvas shadows>
        <Suspense fallback={null}>
          <Sky sunPosition={[100, 20, 100]} />
          <ambientLight intensity={0.6} />
          <directionalLight
            castShadow
            position={[50, 50, 50]}
            intensity={1.5}
            shadow-mapSize-width={2048}
            shadow-mapSize-height={2048}
          />
          <FollowCamera targetRef={controlledObjectRef} offset={cameraOffset} />
          <Scene />
          <Character
            initialState={initialCharacterState}
            playerInput={playerInput}
            isActive={controlMode === ControlMode.Character}
            onStateChange={setCharacterState}
            objectRef={controlMode === ControlMode.Character ? controlledObjectRef : undefined}
          />
          <Car
            initialState={initialCarState}
            playerInput={playerInput}
            isActive={controlMode === ControlMode.Car}
            onStateChange={setCarState}
            objectRef={controlMode === ControlMode.Car ? controlledObjectRef : undefined}
          />
          <Boat
            initialState={initialBoatState}
            playerInput={playerInput}
            isActive={controlMode === ControlMode.Boat}
            onStateChange={setBoatState}
            objectRef={controlMode === ControlMode.Boat ? controlledObjectRef : undefined}
          />
          <Airplane
            initialState={initialAirplaneState}
            playerInput={playerInput}
            isActive={controlMode === ControlMode.Airplane}
            onStateChange={setAirplaneState}
            objectRef={controlMode === ControlMode.Airplane ? controlledObjectRef : undefined}
          />
        </Suspense>
        {process.env.NODE_ENV === 'development' && <Stats />}
      </Canvas>
      <div className="absolute top-4 left-4 p-4 bg-black bg-opacity-70 rounded-lg shadow-xl max-w-sm max-h-60 overflow-y-auto gemini-scrollbar">
        <h2 className="text-xl font-bold mb-2 text-cyan-400">AI Guidance</h2>
        {geminiLoading && <p className="text-sm text-yellow-300">AI is thinking...</p>}
        <p className="text-sm text-gray-200 whitespace-pre-wrap">{geminiMessage}</p>
        {geminiSources.length > 0 && (
          <div className="mt-2 pt-2 border-t border-gray-600">
            <h3 className="text-xs font-semibold text-gray-400 mb-1">Sources:</h3>
            <ul className="list-disc list-inside">
              {geminiSources.map((source, index) => (
                source.web?.uri && ( // Additional check for safety, though filter in getGeminiResponse should handle this
                  <li key={index} className="text-xs text-blue-400 hover:text-blue-300">
                    <a href={source.web.uri} target="_blank" rel="noopener noreferrer">
                      {source.web.title || source.web.uri}
                    </a>
                  </li>
                )
              ))}
            </ul>
          </div>
        )}
      </div>
      <div className="absolute bottom-4 left-4 p-3 bg-black bg-opacity-70 rounded-lg shadow-xl text-xs text-gray-300">
        <p>Controls: [W/S] Move, [A/D] Steer/Rotate</p>
        <p>[E] Interact / Enter/Exit Vehicle</p>
        <p>[Shift] Turbo (in vehicle)</p>
        <p>Current Mode: <span className="font-bold text-yellow-400">{controlMode}</span></p>
      </div>
    </>
  );
};

export default App;
