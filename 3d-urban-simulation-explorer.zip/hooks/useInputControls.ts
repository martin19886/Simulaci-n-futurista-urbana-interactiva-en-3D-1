
import { useState, useEffect, useCallback } from 'react';
import { PlayerInput } from '../types';
import { KEY_W, KEY_S, KEY_A, KEY_D, KEY_E, KEY_SHIFT } from '../constants';

export const useInputControls = (): PlayerInput => {
  const [input, setInput] = useState<PlayerInput>({
    forward: false,
    backward: false,
    left: false,
    right: false,
    interact: false,
    turbo: false,
  });

  const handleKeyDown = useCallback((event: KeyboardEvent) => {
    const key = event.key.toLowerCase();
    setInput(prevInput => {
      let changed = false;
      const newInput = {...prevInput};
      if (key === KEY_W && !prevInput.forward) { newInput.forward = true; changed = true; }
      if (key === KEY_S && !prevInput.backward) { newInput.backward = true; changed = true; }
      if (key === KEY_A && !prevInput.left) { newInput.left = true; changed = true; }
      if (key === KEY_D && !prevInput.right) { newInput.right = true; changed = true; }
      if (key === KEY_E && !prevInput.interact) { newInput.interact = true; changed = true; } // Momentary press
      if (event.key === KEY_SHIFT && !prevInput.turbo) { newInput.turbo = true; changed = true; }
      return changed ? newInput : prevInput;
    });
  }, []);

  const handleKeyUp = useCallback((event: KeyboardEvent) => {
    const key = event.key.toLowerCase();
    setInput(prevInput => {
      let changed = false;
      const newInput = {...prevInput};
      if (key === KEY_W && prevInput.forward) { newInput.forward = false; changed = true; }
      if (key === KEY_S && prevInput.backward) { newInput.backward = false; changed = true; }
      if (key === KEY_A && prevInput.left) { newInput.left = false; changed = true; }
      if (key === KEY_D && prevInput.right) { newInput.right = false; changed = true; }
      if (key === KEY_E && prevInput.interact) { newInput.interact = false; changed = true; } // Reset after key up
      if (event.key === KEY_SHIFT && prevInput.turbo) { newInput.turbo = false; changed = true; }
      return changed ? newInput : prevInput;
    });
  }, []);

  useEffect(() => {
    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [handleKeyDown, handleKeyUp]);

  return input;
};
