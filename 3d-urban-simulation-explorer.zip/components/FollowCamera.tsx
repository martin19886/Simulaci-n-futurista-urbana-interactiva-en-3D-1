
import React, { useRef } from 'react';
import { useThree, useFrame } from '@react-three/fiber';
import * as THREE from 'three';

interface FollowCameraProps {
  targetRef: React.MutableRefObject<THREE.Object3D | null>;
  offset?: [number, number, number];
}

export const FollowCamera: React.FC<FollowCameraProps> = ({ targetRef, offset = [0, 5, 10] }) => {
  const { camera } = useThree();
  const currentPosition = useRef(new THREE.Vector3());
  const currentLookAt = useRef(new THREE.Vector3());

  useFrame((_, delta) => {
    if (targetRef.current) {
      const targetObject = targetRef.current;
      const idealOffset = new THREE.Vector3(...offset);
      
      // Apply target's rotation to the offset
      idealOffset.applyQuaternion(targetObject.quaternion);
      idealOffset.add(targetObject.position);

      const idealLookAt = targetObject.position.clone();
      
      // Smooth camera movement (lerp)
      const lerpFactor = Math.min(delta * 5, 1); // Adjust speed of lerp here
      currentPosition.current.lerp(idealOffset, lerpFactor);
      currentLookAt.current.lerp(idealLookAt, lerpFactor);

      camera.position.copy(currentPosition.current);
      camera.lookAt(currentLookAt.current);
    }
  });

  return null;
};
