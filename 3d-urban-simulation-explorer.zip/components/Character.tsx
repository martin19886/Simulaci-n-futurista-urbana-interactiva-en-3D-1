
import React, { useRef, useEffect } from 'react';
import { useFrame } from '@react-three/fiber';
import { Box, Cylinder } from '@react-three/drei';
import * as THREE from 'three';
import { PlayerInput, EntityState } from '../types';
import { CHARACTER_SPEED, CHARACTER_ROTATION_SPEED } from '../constants';

interface CharacterProps {
  initialState: EntityState;
  playerInput: PlayerInput;
  isActive: boolean;
  onStateChange: (state: EntityState) => void;
  objectRef?: React.MutableRefObject<THREE.Object3D | null>;
}

export const Character: React.FC<CharacterProps> = ({ initialState, playerInput, isActive, onStateChange, objectRef }) => {
  const groupRef = useRef<THREE.Group>(null!);

  useEffect(() => {
    if (groupRef.current) {
      groupRef.current.position.set(...initialState.position);
      groupRef.current.rotation.set(...initialState.rotation);
      if (isActive && objectRef) {
        objectRef.current = groupRef.current;
      }
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isActive, objectRef]); // Only set ref when becoming active or on initial mount

   useEffect(() => { // Update position if externally changed (e.g. exiting vehicle)
    if (groupRef.current) {
      groupRef.current.position.set(...initialState.position);
      groupRef.current.rotation.set(...initialState.rotation);
    }
  }, [initialState.position, initialState.rotation]);


  useFrame((_, delta) => {
    if (!isActive || !groupRef.current) return;

    const speed = CHARACTER_SPEED * delta;
    const rotationSpeed = CHARACTER_ROTATION_SPEED;

    if (playerInput.forward) {
      groupRef.current.translateZ(-speed);
    }
    if (playerInput.backward) {
      groupRef.current.translateZ(speed);
    }
    if (playerInput.left) {
      groupRef.current.rotateY(rotationSpeed);
    }
    if (playerInput.right) {
      groupRef.current.rotateY(-rotationSpeed);
    }
    
    // Ensure character stays on ground - simplistic approach
    groupRef.current.position.y = initialState.position[1];


    onStateChange({
      position: groupRef.current.position.toArray() as [number, number, number],
      rotation: [groupRef.current.rotation.x, groupRef.current.rotation.y, groupRef.current.rotation.z],
    });

    if (objectRef) {
      objectRef.current = groupRef.current;
    }
  });

  return (
    <group ref={groupRef} castShadow receiveShadow>
      {/* Torso */}
      <Box args={[0.5, 1, 0.3]} position={[0, 0.5, 0]} castShadow>
        <meshStandardMaterial color="skyblue" />
      </Box>
      {/* Head */}
      <Box args={[0.4, 0.4, 0.4]} position={[0, 1.2, 0]} castShadow>
        <meshStandardMaterial color="lightpink" />
      </Box>
      {/* Legs */}
      <Cylinder args={[0.1, 0.1, 0.5]} position={[-0.15, -0.25, 0]} castShadow>
        <meshStandardMaterial color="dodgerblue" />
      </Cylinder>
      <Cylinder args={[0.1, 0.1, 0.5]} position={[0.15, -0.25, 0]} castShadow>
        <meshStandardMaterial color="dodgerblue" />
      </Cylinder>
      {/* Arms */}
      <Cylinder args={[0.08, 0.08, 0.4]} position={[-0.3, 0.6, 0]} rotation={[0,0, -Math.PI/6]} castShadow>
        <meshStandardMaterial color="deepskyblue" />
      </Cylinder>
       <Cylinder args={[0.08, 0.08, 0.4]} position={[0.3, 0.6, 0]} rotation={[0,0, Math.PI/6]} castShadow>
        <meshStandardMaterial color="deepskyblue" />
      </Cylinder>
    </group>
  );
};
