
import React, { useRef, useEffect, useState } from 'react';
import { useFrame } from '@react-three/fiber';
import { Box } from '@react-three/drei';
import * as THREE from 'three';
import { PlayerInput, EntityState } from '../../types';
import { VEHICLE_SPEED, VEHICLE_ROTATION_SPEED, VEHICLE_TURBO_MULTIPLIER, VEHICLE_TURBO_DURATION, WATER_LEVEL_Y } from '../../constants';

interface BoatProps {
  initialState: EntityState;
  playerInput: PlayerInput;
  isActive: boolean;
  onStateChange: (state: EntityState) => void;
  objectRef?: React.MutableRefObject<THREE.Object3D | null>;
}

// Define water area boundaries (example)
const WATER_X_MIN = -55; // Matches water plane position [-15, _, 15] and size [80,80] -> -15 - 40 = -55
const WATER_X_MAX = 25;  // -15 + 40 = 25
const WATER_Z_MIN = -25; // 15 - 40 = -25
const WATER_Z_MAX = 55;  // 15 + 40 = 55


export const Boat: React.FC<BoatProps> = ({ initialState, playerInput, isActive, onStateChange, objectRef }) => {
  const groupRef = useRef<THREE.Group>(null!);
  const [isTurboActive, setIsTurboActive] = useState(false);
  const turboTimeoutRef = useRef<number | null>(null); // Changed type to number

  useEffect(() => {
    if (groupRef.current) {
      groupRef.current.position.set(...initialState.position);
      groupRef.current.rotation.set(...initialState.rotation);
      if (isActive && objectRef) {
        objectRef.current = groupRef.current;
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isActive, objectRef]);

  useEffect(() => {
    if (isActive && playerInput.turbo && !isTurboActive) {
      setIsTurboActive(true);
      if (turboTimeoutRef.current) clearTimeout(turboTimeoutRef.current);
      turboTimeoutRef.current = window.setTimeout(() => { // Explicitly use window.setTimeout
        setIsTurboActive(false);
      }, VEHICLE_TURBO_DURATION);
    }
    // Cleanup timeout on component unmount or when dependencies change
     return () => {
      if (turboTimeoutRef.current) {
        clearTimeout(turboTimeoutRef.current);
      }
    };
  }, [isActive, playerInput.turbo, isTurboActive]);

  useFrame((_, delta) => {
    if (!isActive || !groupRef.current) return;

    let currentSpeed = VEHICLE_SPEED * 0.8; // Boats are a bit slower
    if (isTurboActive) {
      currentSpeed *= VEHICLE_TURBO_MULTIPLIER;
    }

    const moveSpeed = currentSpeed * delta;
    const rotationSpeed = VEHICLE_ROTATION_SPEED * 1.2; // Boats turn a bit wider/slower

    const prevPosition = groupRef.current.position.clone();

    if (playerInput.forward) {
      groupRef.current.translateZ(-moveSpeed);
    }
    if (playerInput.backward) {
      groupRef.current.translateZ(moveSpeed / 2);
    }
    
    if (playerInput.forward || playerInput.backward) {
        if (playerInput.left) {
        groupRef.current.rotateY(rotationSpeed);
        }
        if (playerInput.right) {
        groupRef.current.rotateY(-rotationSpeed);
        }
    }

    // Water constraint
    const { x, z } = groupRef.current.position;
    if (x < WATER_X_MIN || x > WATER_X_MAX || z < WATER_Z_MIN || z > WATER_Z_MAX) {
       // Revert to previous position if out of bounds
       groupRef.current.position.copy(prevPosition);
    }
    
    groupRef.current.position.y = initialState.position[1]; // Keep at boat's water level

    onStateChange({
      position: groupRef.current.position.toArray() as [number, number, number],
      rotation: [groupRef.current.rotation.x, groupRef.current.rotation.y, groupRef.current.rotation.z],
    });
    if (objectRef) {
      objectRef.current = groupRef.current;
    }
  });

  return (
    <group ref={groupRef} castShadow receiveShadow visible={true}>
      {/* Hull */}
      <Box args={[1.8, 0.8, 4.5]} position={[0, 0, 0]} castShadow>
        <meshStandardMaterial color={isTurboActive ? "deepskyblue" : "royalblue"} metalness={0.2} roughness={0.4}/>
      </Box>
      {/* Cabin */}
      <Box args={[1.2, 0.6, 1.5]} position={[0, 0.7, -0.5]} castShadow>
        <meshStandardMaterial color="whitesmoke" />
      </Box>
    </group>
  );
};
