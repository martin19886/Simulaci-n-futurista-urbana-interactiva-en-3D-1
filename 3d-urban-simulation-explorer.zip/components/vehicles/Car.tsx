
import React, { useRef, useEffect, useState } from 'react';
import { useFrame } from '@react-three/fiber';
import { Box } from '@react-three/drei';
import * as THREE from 'three';
import { PlayerInput, EntityState } from '../../types';
import { VEHICLE_SPEED, VEHICLE_ROTATION_SPEED, VEHICLE_TURBO_MULTIPLIER, VEHICLE_TURBO_DURATION } from '../../constants';

interface CarProps {
  initialState: EntityState;
  playerInput: PlayerInput;
  isActive: boolean;
  onStateChange: (state: EntityState) => void;
  objectRef?: React.MutableRefObject<THREE.Object3D | null>;
}

export const Car: React.FC<CarProps> = ({ initialState, playerInput, isActive, onStateChange, objectRef }) => {
  const groupRef = useRef<THREE.Group>(null!);
  const [isTurboActive, setIsTurboActive] = useState(false);
  const turboTimeoutRef = useRef<number | null>(null); // Changed type to number

  useEffect(() => {
    if (groupRef.current) {
      groupRef.current.position.set(...initialState.position);
      groupRef.current.rotation.set(...initialState.rotation);
      if (isActive && objectRef) {
        objectRef.current = groupRef.current;
      }
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isActive, objectRef]);

  useEffect(() => {
    if (isActive && playerInput.turbo && !isTurboActive) {
      setIsTurboActive(true);
      if (turboTimeoutRef.current) clearTimeout(turboTimeoutRef.current);
      turboTimeoutRef.current = window.setTimeout(() => { // Explicitly use window.setTimeout
        setIsTurboActive(false);
      }, VEHICLE_TURBO_DURATION);
    }
    // Cleanup timeout on component unmount or when dependencies change
    return () => {
      if (turboTimeoutRef.current) {
        clearTimeout(turboTimeoutRef.current);
      }
    };
  }, [isActive, playerInput.turbo, isTurboActive]);


  useFrame((_, delta) => {
    if (!isActive || !groupRef.current) return;

    let currentSpeed = VEHICLE_SPEED;
    if (isTurboActive) {
      currentSpeed *= VEHICLE_TURBO_MULTIPLIER;
    }
    
    const moveSpeed = currentSpeed * delta;
    const rotationSpeed = VEHICLE_ROTATION_SPEED;

    if (playerInput.forward) {
      groupRef.current.translateZ(-moveSpeed);
    }
    if (playerInput.backward) {
      groupRef.current.translateZ(moveSpeed / 2); // Slower reverse
    }
    
    // Only allow rotation if moving
    if (playerInput.forward || playerInput.backward) {
        if (playerInput.left) {
        groupRef.current.rotateY(rotationSpeed);
        }
        if (playerInput.right) {
        groupRef.current.rotateY(-rotationSpeed);
        }
    }
    
    // Ensure car stays on ground
    groupRef.current.position.y = initialState.position[1];


    onStateChange({
      position: groupRef.current.position.toArray() as [number, number, number],
      rotation: [groupRef.current.rotation.x, groupRef.current.rotation.y, groupRef.current.rotation.z],
    });
    if (objectRef) {
      objectRef.current = groupRef.current;
    }
  });

  return (
    <group ref={groupRef} castShadow receiveShadow visible={true}>
      {/* Body */}
      <Box args={[2, 0.8, 3.5]} position={[0, 0, 0]} castShadow>
        <meshStandardMaterial color={isTurboActive ? "orange" : "crimson"} metalness={0.5} roughness={0.3} />
      </Box>
      {/* Cabin */}
      <Box args={[1.6, 0.7, 1.8]} position={[0, 0.75, -0.2]} castShadow>
        <meshStandardMaterial color="lightslategray" metalness={0.3} roughness={0.5} />
      </Box>
      {/* Wheels - simple boxes */}
      <Box args={[0.4, 0.6, 0.6]} position={[-0.85, -0.1, 1.2]} castShadow><meshStandardMaterial color="black" /></Box>
      <Box args={[0.4, 0.6, 0.6]} position={[0.85, -0.1, 1.2]} castShadow><meshStandardMaterial color="black" /></Box>
      <Box args={[0.4, 0.6, 0.6]} position={[-0.85, -0.1, -1.2]} castShadow><meshStandardMaterial color="black" /></Box>
      <Box args={[0.4, 0.6, 0.6]} position={[0.85, -0.1, -1.2]} castShadow><meshStandardMaterial color="black" /></Box>
    </group>
  );
};
