
import React from 'react';
import { Plane, Box } from '@react-three/drei';
import { RepeatWrapping, TextureLoader } from 'three';
import { useLoader } from '@react-three/fiber';
import { WATER_LEVEL_Y, RUNWAY_Y, ISLAND_Y } from '../constants';

const Ground: React.FC = () => {
  const asphaltTexture = useLoader(TextureLoader, 'https://picsum.photos/seed/asphalt/1024/1024'); // Placeholder
  if (asphaltTexture) {
    asphaltTexture.wrapS = asphaltTexture.wrapT = RepeatWrapping;
    asphaltTexture.repeat.set(50, 50);
  }
  return (
    <Plane args={[200, 200]} rotation={[-Math.PI / 2, 0, 0]} position={[0, 0, 0]} receiveShadow>
      <meshStandardMaterial map={asphaltTexture || undefined} color={asphaltTexture ? undefined : '#444444'} />
    </Plane>
  );
};

const Building: React.FC<{ position: [number, number, number]; size: [number, number, number]; color?: string }> = ({ position, size, color = '#777788' }) => {
  return (
    <Box args={size} position={position} castShadow receiveShadow>
      <meshStandardMaterial color={color} metalness={0.3} roughness={0.6}/>
    </Box>
  );
};

const Water: React.FC = () => {
  return (
    <Plane args={[80, 80]} rotation={[-Math.PI / 2, 0, 0]} position={[-15, WATER_LEVEL_Y, 15]} receiveShadow>
      <meshStandardMaterial color="#337799" opacity={0.8} transparent metalness={0.1} roughness={0.2} />
    </Plane>
  );
};

const Runway: React.FC = () => {
    return (
      <Box args={[8, 1, 40]} position={[20, RUNWAY_Y - 0.5, 20]} castShadow receiveShadow>
        <meshStandardMaterial color="#505050" />
      </Box>
    );
  };

const Island: React.FC<{ position: [number, number, number]; size: [number, number, number] }> = ({ position, size }) => {
    return (
        <Box args={size} position={position} castShadow receiveShadow>
            <meshStandardMaterial color="#8B7355" /> 
        </Box>
    );
};


export const Scene: React.FC = () => {
  return (
    <>
      <Ground />
      <Water />
      <Runway />

      {/* Buildings */}
      <Building position={[-10, 5, -15]} size={[5, 10, 8]} color="#606070" />
      <Building position={[10, 7.5, -20]} size={[6, 15, 6]} color="#505060"/>
      <Building position={[0, 10, -25]} size={[10, 20, 4]} color="#656575"/>
      <Building position={[-20, 6, 0]} size={[4, 12, 12]} color="#556677"/>
      <Building position={[15, 4, 10]} size={[8, 8, 8]} color="#707080"/>

      {/* Islands */}
      <Island position={[-25, ISLAND_Y/2, 25]} size={[10, ISLAND_Y, 15]} />
      <Island position={[-10, ISLAND_Y/2 - 0.3, 30]} size={[8, ISLAND_Y-0.6, 8]} />
    </>
  );
};
