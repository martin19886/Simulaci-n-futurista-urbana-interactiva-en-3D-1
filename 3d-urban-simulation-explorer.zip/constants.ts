
export const CHARACTER_SPEED = 5;
export const CHARACTER_ROTATION_SPEED = Math.PI / 60;

export const VEHICLE_SPEED = 10;
export const VEHICLE_ROTATION_SPEED = Math.PI / 90;
export const VEHICLE_TURBO_MULTIPLIER = 2.5;
export const VEHICLE_TURBO_DURATION = 3000; // ms

export const AIRPLANE_TAKEOFF_SPEED = 15;
export const AIRPLANE_FLYING_SPEED = 20;
export const AIRPLANE_CLIMB_RATE = 2;
export const AIRPLANE_ROLL_RATE = Math.PI / 120;

export const INTERACTION_DISTANCE = 5; // Distance to interact with vehicles

export const CAMERA_OFFSET_CHARACTER: [number, number, number] = [0, 5, 10];
export const CAMERA_OFFSET_VEHICLE: [number, number, number] = [0, 8, 15];

// Key codes (using event.key for better readability)
export const KEY_W = 'w';
export const KEY_S = 's';
export const KEY_A = 'a';
export const KEY_D = 'd';
export const KEY_E = 'e';
export const KEY_SHIFT = 'Shift';

export const GEMINI_MODEL_TEXT = 'gemini-2.5-flash-preview-04-17';

export const WATER_LEVEL_Y = 0.1; // Y-coordinate for water surface
export const RUNWAY_Y = 0.2; // Y-coordinate for runway, slightly above ground
export const ISLAND_Y = 1; // Y-coordinate for islands
