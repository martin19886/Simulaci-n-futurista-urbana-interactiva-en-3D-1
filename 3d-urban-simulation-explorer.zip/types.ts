
import { Vector3 } from 'three';

export enum ControlMode {
  Character = 'CHARACTER',
  Car = 'CAR',
  Boat = 'BOAT',
  Airplane = 'AIRPLANE',
}

export interface PlayerInput {
  forward: boolean;
  backward: boolean;
  left: boolean;
  right: boolean;
  interact: boolean;
  turbo: boolean;
}

export interface EntityState {
  position: [number, number, number];
  rotation: [number, number, number];
}

export interface Vehicle extends EntityState {
  id: string;
  type: ControlMode.Car | ControlMode.Boat | ControlMode.Airplane;
}

export interface GroundingChunkWeb {
  uri?: string; // Made optional
  title?: string; // Made optional
}
export interface GroundingChunk {
  web?: GroundingChunkWeb;
  retrievalQuery?: string;
  text?: string;
}
